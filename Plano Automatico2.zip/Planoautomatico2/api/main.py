import tempfile
from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from fastapi import Request
import firebase_admin
from firebase_admin import credentials, storage
from docx import Document
from io import BytesIO

# Inicializa o Firebase Admin
cred = credentials.Certificate('credenciais.json')
firebase_admin.initialize_app(cred, {
    'storageBucket': 'planos-1a454.appspot.com'
})

app = FastAPI()
templates = Jinja2Templates(directory=".")

def list_files():
    bucket = storage.bucket()
    blobs = bucket.list_blobs()
    return [blob.name for blob in blobs]

def download_docx(doc_name):
    bucket = storage.bucket()
    blob = bucket.blob(f'planos/{doc_name}')
    doc_stream = BytesIO()
    blob.download_to_file(doc_stream)
    doc_stream.seek(0)
    return doc_stream

def fill_docx(doc_stream, escola, data, nome, turma, duracao1, tempo):
    doc = Document(doc_stream)
    replacements = {
        '{escola}': escola,
        '{data}': data,
        '{nome}': nome,
        '{turma}': turma,
        '{duracao1}': duracao1,
        '{tempo}': tempo,
    }

    for p in doc.paragraphs:
        for placeholder, value in replacements.items():
            if placeholder in p.text:
                p.text = p.text.replace(placeholder, value)
    return doc

def save_docx(doc):
    # Usa um arquivo temporário para salvar o documento
    with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as temp_file:
        doc.save(temp_file.name)
        return temp_file.name

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    files = list_files()
    return templates.TemplateResponse("index.html", {"request": request, "files": files})

@app.post("/fill_doc")
async def fill_doc(
        doc_name: str = Form(...),
        escola: str = Form(...),
        data: str = Form(...),
        nome: str = Form(...),
        turma: str = Form(...),
        duracao1: str = Form(...),
        tempo: str = Form(...),
        formato: str = Form(...)
):
    try:
        doc_stream = download_docx(doc_name)
        filled_doc = fill_docx(doc_stream, escola, data, nome, turma, duracao1, tempo)

        if formato == 'docx':
            filled_doc_path = save_docx(filled_doc)
            return FileResponse(filled_doc_path,
                                media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                                filename='plano-final.docx')
        else:
            return {"Mensagem": "Formato inválido. Escolha 'docx'."}
    except Exception:
        return {"Mensagem": "Plano de aula nao encontrado! Por favor, verifique a sua ortografia nos campos preenchidos. Siga Portugues do Portugal"}