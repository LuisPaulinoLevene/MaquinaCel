package mz.mozimei;

import Prevalent.PrevalentUSer;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import mz.mozimei.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;

public class CalcularTecnoActivity extends AppCompatActivity {
    EditText EdtIMEITecno;
    TextView TxtCodigoTecno;
    Button BtnCalcularTecno;
    int primeiro,segundo,terceiro,quarto,quinto,sexto,setmo,oitavo,nono,decimo,decprimeiro,decsegundo,decterceiro,decquarto,decquinto;
    int CODIGO;
    String IMEI;
    /////
    String display;
    private  final long ma=1;
    private String b="blocked";
    // //
    private DatabaseReference ClienteRef;
    //
    private static final  int CAMERA_REQUEST_CODE=200;
    private static final  int STORAGE_REQUEST_CODE=400;
    private static final  int IMAGE_PICK_GALLERY_CODE=1000;
    private static final  int IMAGE_PICK_CAMERA_CODE=1001;
    ImageView image,image1;
    String cameraPermission[];
    String storagePermission[];
    Uri image_uri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcular_tecno);
        EdtIMEITecno =findViewById(R.id.EdtIMEITecno);
        TxtCodigoTecno =findViewById(R.id.txtCodigoTecno);
        BtnCalcularTecno =findViewById(R.id.btn_CalcularTecno);
        ///***********************************Ablisio Sarmento//////////
        image=findViewById(R.id.FTTecno2);
        image1=findViewById(R.id.FTTecno);
        //Camera Permission
        cameraPermission =new String[]{Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE};
        //storage Permission
        storagePermission=new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};
        image1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImageImportDialgo();
            }
        });
        ///***********************************Ablisio Sarmento//////////
        ClienteRef= FirebaseDatabase.getInstance().getReference().child("usuarios")
                .child(String.valueOf(PrevalentUSer.currentOnlineUser.getContacto()));
        BtnCalcularTecno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(EdtIMEITecno.getText().toString())){
                    Toast.makeText(CalcularTecnoActivity.this, "Enter the device's Imei", Toast.LENGTH_SHORT).show();
                }else{
                    if (EdtIMEITecno.getText().toString().length()<15){
                        Toast.makeText(CalcularTecnoActivity.this, "The Imei must be neither greater nor less than 15 Digits!", Toast.LENGTH_SHORT).show();
                    }else{
                        long sarmento= PrevalentUSer.currentOnlineUser.getCreditos();
                        if (sarmento<=0){
                            //Toast.makeText(CalcularHisenseActivity.this, "Os seus creditos sao insuficientes, recaregue a sua conta!", Toast.LENGTH_SHORT).show();
                            balanceOFF(MainActivity.class);
                            BtnCalcularTecno.setEnabled(false);
                            BtnCalcularTecno.setVisibility(View.GONE);
                        }else{
                            if (isOnline()){
                                if (PrevalentUSer.currentOnlineUser.getAccountstatus().equals("allowed")){
                                    Calcular();
                                }else{
                                    Toast.makeText(CalcularTecnoActivity.this, "Your account is locked, contact the Admin +258842306947", Toast.LENGTH_SHORT).show();
                                }

                            }else{
                                Internet(CalcularTecnoActivity.class);
                                Toast.makeText(CalcularTecnoActivity.this, "Check your internet Connection!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                }
            }
        });
        TxtCodigoTecno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(TxtCodigoTecno.getText().toString())){
                    ClipboardManager _clipboard = (ClipboardManager) CalcularTecnoActivity.this.getSystemService(Context.CLIPBOARD_SERVICE);
                    _clipboard.setText(TxtCodigoTecno.getText().toString());
                    Toast.makeText(CalcularTecnoActivity.this, "Imei Copied Successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(CalcularTecnoActivity.this, "Calculate an Imei to be able to Copy", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void  Calcular(){
        BtnCalcularTecno.setEnabled(false);
        BtnCalcularTecno.setVisibility(View.GONE);
        //Divisao dos digitos;
        IMEI= EdtIMEITecno.getText().toString();
        /*String array[] = IMEI.split (" ");
        int resultado[] = new int[14];
        for(int i = 0; i < 14; i++) {
            resultado[i] = Integer.parseInt(array[i]);
        }*/
        char[] digitos =  IMEI.toCharArray();
        primeiro=Integer.parseInt(String.valueOf(digitos[0]));
        segundo=Integer.parseInt(String.valueOf(digitos[1]));
        terceiro=Integer.parseInt(String.valueOf(digitos[2]));
        quarto=Integer.parseInt(String.valueOf(digitos[3]));
        quinto=Integer.parseInt(String.valueOf(digitos[4]));
        sexto=Integer.parseInt(String.valueOf(digitos[5]));
        setmo=Integer.parseInt(String.valueOf(digitos[6]));
        oitavo=Integer.parseInt(String.valueOf(digitos[7]));
        nono=Integer.parseInt(String.valueOf(digitos[8]));
        decimo=Integer.parseInt(String.valueOf(digitos[9]));
        decprimeiro=Integer.parseInt(String.valueOf(digitos[10]));
        decsegundo=Integer.parseInt(String.valueOf(digitos[11]));
        decterceiro=Integer.parseInt(String.valueOf(digitos[12]));
        decquarto=Integer.parseInt(String.valueOf(digitos[13]));
        decquinto=Integer.parseInt(String.valueOf(digitos[14]));
        int segprimeiro,segsegundo,segterceiro,segquarto,segquinto,segsexto,segsetmo;
        segprimeiro= this.primeiro +segundo;
        segsegundo=terceiro+quarto;
        segterceiro=quinto+sexto;
        segquarto=setmo+oitavo;
        segquinto=nono+decimo;
        segsexto=decprimeiro+decsegundo;
        segsetmo=decterceiro+decquarto;
        String a,b,c,d,e,f,g,h;
        a=String.valueOf(segprimeiro);
        b=String.valueOf(segsegundo);
        c=String.valueOf(segterceiro);
        d=String.valueOf(segquarto);
        e=String.valueOf(segquinto);
        f=String.valueOf(segsexto);
        g=String.valueOf(segsetmo);
        h=String.valueOf(primeiro);
        if (a.length()>1) a = a.substring (1);
        if (b.length()>1) b = b.substring (1);
        if (c.length()>1) c = c.substring (1);
        if (d.length()>1) d = d.substring (1);
        if (e.length()>1) e = e.substring (1);
        if (f.length()>1) f = f.substring (1);
        if (g.length()>1) g = g.substring (1);
        display=a+b+c+d+e+f+g+h;
        //MOstrar Codigo
        TxtCodigoTecno.setText(display);
        updateCredito();
    }

    public  void Update(Class<CalcularTecnoActivity> view){
        View mView=getLayoutInflater().inflate(R.layout.check_server_dialog,null);
        final Button btn_welcome;
        btn_welcome=(Button)mView.findViewById(R.id.btn_dialog_server);
        final AlertDialog.Builder alert= new AlertDialog.Builder(this);
        alert.setView(mView);
        final AlertDialog alertDialog=alert.create();
        alertDialog.setCanceledOnTouchOutside(false);
        btn_welcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();

            }
        });
        alertDialog.show();

    }
    public  void Internet(Class<CalcularTecnoActivity> view){
        View mView=getLayoutInflater().inflate(R.layout.check_internet_dialog,null);
        final Button btn_welcome;
        btn_welcome=(Button)mView.findViewById(R.id.btn_dialog_internet);
        final AlertDialog.Builder alert= new AlertDialog.Builder(this);
        alert.setView(mView);
        final AlertDialog alertDialog=alert.create();
        alertDialog.setCanceledOnTouchOutside(false);
        btn_welcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();

            }
        });
        alertDialog.show();

    }
    private void udone(Class<CalcularTecnoActivity> view)
    {
        BtnCalcularTecno.setEnabled(false);
        BtnCalcularTecno.setVisibility(View.GONE);
        View mView=getLayoutInflater().inflate(R.layout.udone_dialog,null);
        final Button btn_welcome;
        final TextView txt_code;
        txt_code=(TextView) mView.findViewById(R.id.txtCodigo);
        txt_code.setText(display);
        txt_code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(txt_code.getText().toString())){
                    ClipboardManager _clipboard = (ClipboardManager)  CalcularTecnoActivity.this.getSystemService(Context.CLIPBOARD_SERVICE);
                    _clipboard.setText(txt_code.getText().toString());
                    Toast.makeText(  CalcularTecnoActivity.this, "Imei Copiado com Sucesso", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(  CalcularTecnoActivity  .this, "Calcule um Imei para poder Copiar", Toast.LENGTH_SHORT).show();
                }
            }

        });
        btn_welcome=(Button)mView.findViewById(R.id.btn_dialog_udone);
        final AlertDialog.Builder alert= new AlertDialog.Builder(this);
        alert.setView(mView);
        final AlertDialog alertDialog=alert.create();
        alertDialog.setCanceledOnTouchOutside(false);
        btn_welcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(txt_code.getText().toString())){
                    ClipboardManager _clipboard = (ClipboardManager) CalcularTecnoActivity  .this.getSystemService(Context.CLIPBOARD_SERVICE);
                    _clipboard.setText(txt_code.getText().toString());
                    Toast.makeText(  CalcularTecnoActivity  .this, "Imei Copiado com Sucesso", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(  CalcularTecnoActivity  .this, "Calcule um Imei para poder Copiar", Toast.LENGTH_SHORT).show();
                }
                startActivity(new Intent(  CalcularTecnoActivity  .this,ActivityModelos.class));
                finish();

            }
        });
        alertDialog.show();

    }




    private void updateCredito() {
        BtnCalcularTecno.setEnabled(false);
        BtnCalcularTecno.setVisibility(View.GONE);
        ClienteRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    long s= (long) snapshot.child("creditos").getValue();

                    PrevalentUSer.currentOnlineUser.setCreditos(s);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        //
        HashMap< String, Object> userdataMap=new HashMap<>();
        long v=PrevalentUSer.currentOnlineUser.getCreditos();
        long v1=v-1;
        long v2=v+1;
        if (v>v1){
            // Toast.makeText(CalculationByGenericSprdActivity.this, "Reduziu", Toast.LENGTH_SHORT).show();
            userdataMap.put("creditos",PrevalentUSer.currentOnlineUser.getCreditos()-ma);
        }else{
            if (v<v2){
                //Toast.makeText(CalculationByGenericSprdActivity.this, "Subiu", Toast.LENGTH_SHORT).show();
                userdataMap.put("creditos",PrevalentUSer.currentOnlineUser.getCreditos()-ma);
                userdataMap.put("accountstatus",b);
                PrevalentUSer.currentOnlineUser.setAccountstatus(b);
            }else{
                //Toast.makeText(CalculationByGenericSprdActivity.this, "Subiu", Toast.LENGTH_SHORT).show();
                userdataMap.put("creditos",PrevalentUSer.currentOnlineUser.getCreditos()-ma);
                userdataMap.put("accountstatus",b);
                PrevalentUSer.currentOnlineUser.setAccountstatus(b);
            }

        }

        ClienteRef.updateChildren(userdataMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            udone(CalcularTecnoActivity.class);
                            Toast.makeText( CalcularTecnoActivity .this, "-1 Credit", Toast.LENGTH_SHORT).show();
                        }

                    }
                });


    }
    public  void balanceOFF(Class<MainActivity> view){
        BtnCalcularTecno.setEnabled(false);
        BtnCalcularTecno.setVisibility(View.GONE);
        View mView=getLayoutInflater().inflate(R.layout.balance_dialog,null);
        final Button btn_welcome;
        btn_welcome=(Button)mView.findViewById(R.id.btn_dialog_balance);
        final AlertDialog.Builder alert= new AlertDialog.Builder(this);
        alert.setView(mView);
        final AlertDialog alertDialog=alert.create();
        alertDialog.setCanceledOnTouchOutside(false);
        btn_welcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CalcularTecnoActivity.this,MainActivity.class));
            }
        });
        alertDialog.show();

    }
    public boolean isOnline() {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
        return manager.getActiveNetworkInfo() != null &&
                manager.getActiveNetworkInfo().isConnectedOrConnecting();
    }

    public void showImageImportDialgo(){
        String [] items={"Camera", "Gallery"};
        AlertDialog.Builder dialog =new AlertDialog.Builder(this);
        //tiile
        dialog.setTitle("Selecione a Imagem");
        dialog.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (i==0){
                    //camera opction cliked
                    if (!checkCameraPermission()){
                        requesrCameraPermission();
                    }else{
                        //permission allowed, take picture
                        pickCamera();
                    }
                }
                if (i==1){
                    //gallery Option Clicked
                    if (!checkStoragePermission()){
                        requesrStoragePermission();
                    }else{
                        //permission allowed, take picture
                        pickGallery();
                    }
                }

            }
        });
        dialog.create().show();
    }
    private void pickGallery() {
        //intent to pickimage from gallery
        Intent intent=new Intent(Intent.ACTION_PICK);
        //set intent type to image
        intent.setType("image/*");
        startActivityForResult(intent,IMAGE_PICK_GALLERY_CODE);

    }
    private void pickCamera() {
        //intent to take image from camera high
        ContentValues values=new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "NewPic");
        values.put(MediaStore.Images.Media.DESCRIPTION, "Image To text");
        image_uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);

        Intent cameraIntent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(cameraIntent, IMAGE_PICK_CAMERA_CODE);

    }
    private void requesrStoragePermission() {
        ActivityCompat.requestPermissions(this,storagePermission,STORAGE_REQUEST_CODE);
    }
    private void requesrCameraPermission() {
        ActivityCompat.requestPermissions(this,cameraPermission,CAMERA_REQUEST_CODE);
    }
    private boolean checkCameraPermission() {
        boolean result= ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA)==(PackageManager.PERMISSION_GRANTED);
        boolean result1=ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)==(PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }
    private boolean checkStoragePermission() {
        boolean result=ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)==(PackageManager.PERMISSION_GRANTED);
        return result;
    }
    //Hannle permition result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case CAMERA_REQUEST_CODE:
                if (grantResults.length>0){
                    boolean cameraAccepted=grantResults[0]==
                            PackageManager.PERMISSION_GRANTED;
                    boolean writeStorageAccepted=grantResults[0]==
                            PackageManager.PERMISSION_GRANTED;
                    if (cameraAccepted && writeStorageAccepted){
                        pickCamera();
                    }else {
                        Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                        //Camera Permission
                        cameraPermission =new String[]{Manifest.permission.CAMERA,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE};

                    }
                }
            case STORAGE_REQUEST_CODE:
                if (grantResults.length>0){
                    boolean writeStorageAccepted=grantResults[0]==
                            PackageManager.PERMISSION_GRANTED;
                    if ( writeStorageAccepted){
                        pickGallery();
                    }else {
                        Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                        //storage Permission
                        storagePermission=new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    }
                }
                break;
        }

    }
    //Handle image result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //got image from gallery
        // super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == IMAGE_PICK_GALLERY_CODE) {
                //got image from gallery now crop it
                CropImage.activity(data.getData())
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .start(this);//enable image guidelines

            }
            if (requestCode == IMAGE_PICK_CAMERA_CODE) {
                //got image from cameranow crop it
                CropImage.activity(image_uri)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .start(this);//enable image guidelines
            }
        }
        //get cropped image
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();//get image uri
                //set image to image view
                image.setImageURI(resultUri);
                //get Drawabble bitmap for text recognetion
                BitmapDrawable bitmapDrawable = (BitmapDrawable) image.getDrawable();
                Bitmap bitmap = bitmapDrawable.getBitmap();
                TextRecognizer recognizer = new TextRecognizer.Builder((getApplicationContext())).build();

                if (!recognizer.isOperational()) {
                    Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
                } else {
                    Frame frame = new Frame.Builder().setBitmap(bitmap).build();
                    SparseArray<TextBlock> items = recognizer.detect(frame);
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < items.size(); i++) {
                        TextBlock myitem = items.valueAt(i);
                        sb.append(myitem.getValue());
                        sb.append("\n");
                    }
                    // setText to edit IMEITEXT
                    EdtIMEITecno.setText(sb.toString());

                }
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                //if there is any error show it
                Exception error = result.getError();
                Toast.makeText(this, "" + error, Toast.LENGTH_SHORT).show();

            }
        }
    }
}