import os
import firebase_admin
from firebase_admin import credentials, storage
from docx import Document
from io import BytesIO

# Inicialize o Firebase Admin
cred = credentials.Certificate('credenciais.json')
firebase_admin.initialize_app(cred, {
    'storageBucket': 'planos-1a454.appspot.com'
})

def list_files():
    bucket = storage.bucket()
    blobs = bucket.list_blobs()

    print("Carregando planos, aguarde:")
    for blob in blobs:
        print()

def download_docx(doc_name):
    bucket = storage.bucket()
    blob = bucket.blob(f'planos/{doc_name}')
    print(f'Tentando baixar: planos/{doc_name}')
    try:
        doc_stream = BytesIO()
        blob.download_to_file(doc_stream)
        doc_stream.seek(0)
        return doc_stream
    except Exception as e:
        print(f'Erro ao baixar o arquivo: {e}')
        raise

def fill_docx(doc_stream, campo1, campo2):
    doc = Document(doc_stream)
    for p in doc.paragraphs:
        if '{campo1}' in p.text:
            p.text = p.text.replace('{campo1}', campo1)
        if '{campo2}' in p.text:
            p.text = p.text.replace('{campo2}', campo2)

    # Definindo o caminho da pasta de downloads
    downloads_folder = os.path.join(os.path.expanduser('~'), 'Downloads')
    base_filename = 'plano-final'
    extension = '.docx'
    filled_doc_path = os.path.join(downloads_folder, f'{base_filename}{extension}')

    # Incrementa o número se o arquivo já existir
    counter = 1
    while os.path.exists(filled_doc_path):
        filled_doc_path = os.path.join(downloads_folder, f'{base_filename}_{counter}{extension}')
        counter += 1

    doc.save(filled_doc_path)  # Salva o documento na pasta de downloads
    return filled_doc_path

if __name__ == "__main__":
    list_files()
    doc_name = input("Digite o nome do documento (com extensão, por exemplo, 1_portugues_escola_adjetivo_40): ")
    campo1 = input("Campo 1: ")
    campo2 = input("Campo 2: ")

    try:
        doc_stream = download_docx(doc_name)
        filled_doc_path = fill_docx(doc_stream, campo1, campo2)
        print(f'Documento preenchido salvo na pasta de downloads como: {filled_doc_path}')
    except Exception as e:
        print(f'Erro: {e}')
