import os
from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from fastapi import Request
import firebase_admin
from firebase_admin import credentials, storage
from docx import Document
from io import BytesIO
from fpdf import FPDF

# Inicialize o Firebase Admin
cred = credentials.Certificate('credenciais.json')
firebase_admin.initialize_app(cred, {
    'storageBucket': 'planos-1a454.appspot.com'
})

app = FastAPI()
templates = Jinja2Templates(directory=".")

def list_files():
    bucket = storage.bucket()
    blobs = bucket.list_blobs()
    return [blob.name for blob in blobs]

def download_docx(doc_name):
    bucket = storage.bucket()
    blob = bucket.blob(f'planos/{doc_name}')
    doc_stream = BytesIO()
    blob.download_to_file(doc_stream)
    doc_stream.seek(0)
    return doc_stream

def fill_docx(doc_stream, escola, data, nome, turma, duracao1, duracao2, duracao3, duracao4, duracao5):
    doc = Document(doc_stream)
    for p in doc.paragraphs:
        p.text = p.text.replace('{escola}', escola)
        p.text = p.text.replace('{data}', data)
        p.text = p.text.replace('{nome}', nome)
        p.text = p.text.replace('{turma}', turma)
        p.text = p.text.replace('{duracao1}', duracao1)
        p.text = p.text.replace('{duracao2}', duracao2)
        p.text = p.text.replace('{duracao3}', duracao3)
        p.text = p.text.replace('{duracao4}', duracao4)
        p.text = p.text.replace('{duracao5}', duracao5)
    return doc

def save_docx(doc, base_filename):
    downloads_folder = os.path.join(os.path.expanduser('~'), 'Downloads')
    filled_doc_path = os.path.join(downloads_folder, f'{base_filename}.docx')
    counter = 1
    while os.path.exists(filled_doc_path):
        filled_doc_path = os.path.join(downloads_folder, f'{base_filename}_{counter}.docx')
        counter += 1
    doc.save(filled_doc_path)
    return filled_doc_path

def save_as_pdf(doc, base_filename):
    downloads_folder = os.path.join(os.path.expanduser('~'), 'Downloads')
    filled_pdf_path = os.path.join(downloads_folder, f'{base_filename}.pdf')
    counter = 1
    while os.path.exists(filled_pdf_path):
        filled_pdf_path = os.path.join(downloads_folder, f'{base_filename}_{counter}.pdf')
        counter += 1

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    for p in doc.paragraphs:
        pdf.set_font("Arial", size=12)
        pdf.multi_cell(0, 10, p.text)

    pdf.output(filled_pdf_path)
    return filled_pdf_path

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    files = list_files()
    return templates.TemplateResponse("index.html", {"request": request, "files": files})

@app.post("/fill_doc")
async def fill_doc(
    doc_name: str = Form(...),
    escola: str = Form(...),
    data: str = Form(...),
    nome: str = Form(...),
    turma: str = Form(...),
    duracao1: str = Form(...),
    duracao2: str = Form(...),
    duracao3: str = Form(...),
    duracao4: str = Form(...),
    duracao5: str = Form(...),
    formato: str = Form(...)
):
    try:
        doc_stream = download_docx(doc_name)
        filled_doc = fill_docx(doc_stream, escola, data, nome, turma, duracao1, duracao2, duracao3, duracao4, duracao5)

        if formato == 'docx':
            filled_doc_path = save_docx(filled_doc, 'plano-final')
            return FileResponse(filled_doc_path, media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document', filename='plano-final.docx')
        elif formato == 'pdf':
            filled_pdf_path = save_as_pdf(filled_doc, 'plano-final')
            return FileResponse(filled_pdf_path, media_type='application/pdf', filename='plano-final.pdf')
        else:
            return {"error": "Formato inválido. Escolha 'docx' ou 'pdf'."}
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
